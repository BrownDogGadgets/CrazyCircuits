<!--- start title --->
# 2x2 Current-Limited Green SMT LED Module v1.0
A Lego-compatible Crazy Circuits module

- Updated: 9 May 2018
- Website: http://browndoggadgets.com/
- Company: Brown Dog Gadgets
- License: CERN Open Hardware License v1.2.
<!--- end title --->

THIS IS THE DESCRIPTION SECTION. REPLACE IT WITH A DESCRIPTION.

<!--- bom start --->
### Bill of Materials


<!--- bom end --->

### Manufacturing Notes

This board must be v-scored. Do not panelize with support tabs or mousebites.

![Assembly Diagram](assembly.png)

![Gerber Preview](preview.png)

